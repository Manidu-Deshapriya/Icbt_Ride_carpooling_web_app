self.assetsManifest = {
  "version": "EPXoaH9E",
  "assets": [
    {
      "hash": "sha256-TKbWsc5gCE+04slSkrqeNGTb7K8LiRW72Tm+1gzKxqU=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.wp5b4xwrtz.wasm"
    },
    {
      "hash": "sha256-qPvavUxiWPAj51uJSf4LOekNKr4akGxRwNr0tHTe7iU=",
      "url": "_framework/Microsoft.AspNetCore.Components.4payhwuyuh.wasm"
    },
    {
      "hash": "sha256-AqlQLnd2AUu1G5e+NO3E6tGfGEty0Vbudprc7K4DUhI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ec8b0m8vzy.wasm"
    },
    {
      "hash": "sha256-e4X4HowGyVJz7RZ2UWcSe9mssqm1IFxF6A1+4hM6+bk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.j6d7zpk03e.wasm"
    },
    {
      "hash": "sha256-ic64++0UYs3SvlBLdn4+qwNWqwSG407oUE8u0eu16ak=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.jt9rzx6tc4.wasm"
    },
    {
      "hash": "sha256-j++RGo33BhgVa0g5y83+TSz6cs3qmH+A5uEXVKZhtr8=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.bhaqktdl3q.wasm"
    },
    {
      "hash": "sha256-foTztPRrzoq1jElVsdRv+okt60TEvQeYphwV9t9NDKI=",
      "url": "_framework/Microsoft.CSharp.y8cabdi7yj.wasm"
    },
    {
      "hash": "sha256-A8e6zZwhOqf7lDQqbbCYcAUv4wGE9aQxOo4WyYxR//0=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.99zm1jdh75.lib.module.js"
    },
    {
      "hash": "sha256-RfVSLzqQEeeGURXg5fCxB/7pjzOLGNHC2cDbIQC7thQ=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.r0uvx0ebhi.wasm"
    },
    {
      "hash": "sha256-qOTZIeG9FsN1IhAycfVSHdCrxcSAjUo5paRUEfUJYhI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.wa2ojg94fi.wasm"
    },
    {
      "hash": "sha256-L5Yax0NPgj+DBfLt7lTLrH7RZVUZ/GeLukF9oyqJ7pU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.l7o5knh4f1.wasm"
    },
    {
      "hash": "sha256-XJGOiagKd+9+kp4Ty7ffOtSndz0apzO8w53DJnndXmI=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.ke1t9ns7xl.wasm"
    },
    {
      "hash": "sha256-OMRxiJp+p0LFgTIPl3n6LciGXvfYIdsr/Q88sETEF4w=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.k1hilos7yb.wasm"
    },
    {
      "hash": "sha256-7DgCCV/LB2eNVzPeNmZ5m2thp6g2kVsit8sogYccXwQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.s6epnzhbd8.wasm"
    },
    {
      "hash": "sha256-rmpyVV0DOgiihi5oxsjrJb01S8m67/Z7tnu/auVgXRw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.q6idsb19uh.wasm"
    },
    {
      "hash": "sha256-AWrVpqzFnmO0tCoEXAH0O7cE33X0Q6ZAa8lm5FRsMQs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.nun950pku8.wasm"
    },
    {
      "hash": "sha256-1HqPfTJfvXForO2lQylRMNXcKDMdF9iD4VZSdaAX5qk=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.s62vewhs76.wasm"
    },
    {
      "hash": "sha256-BaaWcXtZnSfywb3RXJuUpPEO8cLvZvlVHj3RJ10hPi0=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.f7zn8s1thp.wasm"
    },
    {
      "hash": "sha256-QNT4BJu7GuqNeD1vP+7WrlS/DU4fGK5J5eUsqmFJ4us=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.woov9lkdcy.wasm"
    },
    {
      "hash": "sha256-7GjBXcHfSzByJQUNWXPp0f32BDtR3+Ti4+rkizb4Ljo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.4uvrzrkcx9.wasm"
    },
    {
      "hash": "sha256-LyxUtk8WTHguCUKCEwF2EMVVVVGlw07/472TEvDsVfE=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.jnewm5d55t.wasm"
    },
    {
      "hash": "sha256-/h+gE4OLQdh3yuKWe0r8/2Si4zxcgw/fbOrbjMlX/ys=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.62zefycurg.wasm"
    },
    {
      "hash": "sha256-V9FEOzDldETmKyiW3FTnoHpCZ4AZvoexnPaEIr09WZE=",
      "url": "_framework/Microsoft.Extensions.Logging.xispqyz68y.wasm"
    },
    {
      "hash": "sha256-pnQwodkGYFmAdSWA6bpOdTxxgWZdqCkOlv0Ku086DvE=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.i2sp1sqcbf.wasm"
    },
    {
      "hash": "sha256-a/pTUQjNwOxhBz/lZgqVyyTyXrbdvyuKnFNyaVNH0Z0=",
      "url": "_framework/Microsoft.Extensions.Options.bs7sofzszu.wasm"
    },
    {
      "hash": "sha256-RgwNm087C7Ho0ns9NEvi/NHblJKJLGtNQvt9F9cpNrc=",
      "url": "_framework/Microsoft.Extensions.Primitives.ub9q6nskn2.wasm"
    },
    {
      "hash": "sha256-+vj2jK2O52sn5ULpvYCNDVIjlE7JxEgdA5PDj/ukV6k=",
      "url": "_framework/Microsoft.Extensions.Validation.y25xlv978u.wasm"
    },
    {
      "hash": "sha256-yZy5My09/M7owHVzBcnK3BPDrUtQH3/wmFTaiPscAgo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.vi1uw8swyy.wasm"
    },
    {
      "hash": "sha256-ydDa5CE8UQzUry68CwEPAVbu361httdsDXT2AQmuMK0=",
      "url": "_framework/Microsoft.JSInterop.zhfbg74p0e.wasm"
    },
    {
      "hash": "sha256-WdAu9w+/3N6zBiVnPDG93KylB3tMbEvzetW+JVs/phQ=",
      "url": "_framework/Microsoft.VisualBasic.Core.rj6qwnj2np.wasm"
    },
    {
      "hash": "sha256-xkh4dkn7gNe1WLAQe3cfm3CjdRVNcJvlpSSdHWynwrI=",
      "url": "_framework/Microsoft.VisualBasic.m5z1bpmsgy.wasm"
    },
    {
      "hash": "sha256-ulM/aFba69M17/Tj1tuJ2PpvdQPnNbGtRVryXQ4hBpo=",
      "url": "_framework/Microsoft.Win32.Primitives.i6x74v9vcb.wasm"
    },
    {
      "hash": "sha256-zigLwYnX2uS92hS70FRqXnZISw2C3v0KY6hKX+fXkA0=",
      "url": "_framework/Microsoft.Win32.Registry.y4gq7fo2lp.wasm"
    },
    {
      "hash": "sha256-Msxz+VaXeSzLcO+27REusA3i8rZyDPExRwGOEKzVK2M=",
      "url": "_framework/System.AppContext.2bkkwkya64.wasm"
    },
    {
      "hash": "sha256-ktsOwh8KMvMN3Q8A2Mb8Y71n8aEHhVV1xQZzvE2Npyk=",
      "url": "_framework/System.Buffers.28ngaukdh3.wasm"
    },
    {
      "hash": "sha256-AJ/sh3LfpzJ6U8IlpLtJlxr7CkJA4R3q8GfHYYLuP7Q=",
      "url": "_framework/System.Collections.0wg2pdla5w.wasm"
    },
    {
      "hash": "sha256-5gzik54yVqs8LFsqbaXng6lrn3RhlMDfCC8jLq2VZHk=",
      "url": "_framework/System.Collections.Concurrent.uigxbozvg6.wasm"
    },
    {
      "hash": "sha256-6w1JgRvP2NIlEP//vr+XQFKoJRWi0F+a6pwJB59tq6U=",
      "url": "_framework/System.Collections.Immutable.jity4go0mw.wasm"
    },
    {
      "hash": "sha256-rVmOtWPpzaYEkyK81lYUn46nwxbzLjFlSj27xuHuoUg=",
      "url": "_framework/System.Collections.NonGeneric.t4c1msu741.wasm"
    },
    {
      "hash": "sha256-55c3YH9310sCKy6fGqY4Zllu/y8OvSsTYjHn6vgtSks=",
      "url": "_framework/System.Collections.Specialized.rjq2931kbi.wasm"
    },
    {
      "hash": "sha256-tctQ8UYwJJ8shbwNq007DYmG7LPwqPz+S0ofwAfcbO8=",
      "url": "_framework/System.ComponentModel.Annotations.x1bvmbqcbl.wasm"
    },
    {
      "hash": "sha256-uIBMcrYQTLgnbuFLK9AicbBy9f1zxigmcq4uOhvRZ3c=",
      "url": "_framework/System.ComponentModel.DataAnnotations.0ugm2kn0ef.wasm"
    },
    {
      "hash": "sha256-qr6WZ92/fTRJqDjbCzCtcyRISjqpy6THwhvvVptQPs8=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.iqz7yfxk0z.wasm"
    },
    {
      "hash": "sha256-XoOP7YWbPst7iwpA+IVsqnFj35UVSNLQX0qd95WX50A=",
      "url": "_framework/System.ComponentModel.Primitives.66wyka365l.wasm"
    },
    {
      "hash": "sha256-bQZSZ/geEtNaQeXITxyPdOnz5maRkPb0OLmq5b8dBfk=",
      "url": "_framework/System.ComponentModel.TypeConverter.le29ulsuyy.wasm"
    },
    {
      "hash": "sha256-TK2nsOyraXFIh5vQiUCbhr1pLr+FmtVFfbPV0bsZvA4=",
      "url": "_framework/System.ComponentModel.wj8g6avob9.wasm"
    },
    {
      "hash": "sha256-W8cY5EWSRm4MysMCu596PIjDOw7/PGHbGXOo9q0cV8M=",
      "url": "_framework/System.Configuration.7xj6hflys1.wasm"
    },
    {
      "hash": "sha256-Aeyntn8KICi8KijwpeMGqeuLLrf5re9RB8xfbQD+fuk=",
      "url": "_framework/System.Console.bdauwtppto.wasm"
    },
    {
      "hash": "sha256-QnFF7W0rRqgKv3dhgaDpxeIv0rGcJmcd2TC4pwMfIhs=",
      "url": "_framework/System.Core.63xjv55d3c.wasm"
    },
    {
      "hash": "sha256-zD75iwjfjKKb57d/N4AYDNHvJ6nlzcKqI86L1GCKqFI=",
      "url": "_framework/System.Data.Common.or5475be6q.wasm"
    },
    {
      "hash": "sha256-DncPkqYn3WSSuOXGrXqqDORmp24KsFKLbpo+0kYEKrc=",
      "url": "_framework/System.Data.DataSetExtensions.aie27nz2fz.wasm"
    },
    {
      "hash": "sha256-bE6W63dBZbAllE7txwGlEzFzTfKrHlSzzWBPrCOaw2E=",
      "url": "_framework/System.Data.s403jyj13x.wasm"
    },
    {
      "hash": "sha256-etzdUlIlT6ITWKDVaYadkvzxVF6uXsOwpAGEfRUnJLo=",
      "url": "_framework/System.Diagnostics.Contracts.awjvmobi6a.wasm"
    },
    {
      "hash": "sha256-p9AUpWapiBUcVVNRFi/p5xCLlcbZQE51E45GvIyG8ao=",
      "url": "_framework/System.Diagnostics.Debug.zd32j0e68b.wasm"
    },
    {
      "hash": "sha256-MSH2kpV4JRkQdze0/1G3U9hK1KybKDnKOvkaU7mYrG8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.h063kza90u.wasm"
    },
    {
      "hash": "sha256-wYtSW2PUGZABZMPyfxFKdw4E/wKwaHYfMzeSE+LtvXg=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.5faw37z8re.wasm"
    },
    {
      "hash": "sha256-JNVVDKXz5lryO6yeAVcogoktKW0wn9Gzk18oFvUvW7Y=",
      "url": "_framework/System.Diagnostics.Process.85y49vqmlw.wasm"
    },
    {
      "hash": "sha256-ZidOHreDMi/G8aTupFo/T2T/sI9Azq+qCgFlQTG+MXg=",
      "url": "_framework/System.Diagnostics.StackTrace.y2jslxj8se.wasm"
    },
    {
      "hash": "sha256-Gq3UhJVGKCsKOSadrTJmeBoEBIB1aQJ72wi830/RcTM=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.ubfqtow1rg.wasm"
    },
    {
      "hash": "sha256-Y0UtthJI9vonI4z+/+qVeMuu9BvQseV3W5Kqiok/ih0=",
      "url": "_framework/System.Diagnostics.Tools.fxjm3tg3oa.wasm"
    },
    {
      "hash": "sha256-7ruz7b/4taN1hslEvPDNya7jlAq9S1zU7lmtSSakJ3c=",
      "url": "_framework/System.Diagnostics.TraceSource.m2df4u53h3.wasm"
    },
    {
      "hash": "sha256-6tlwP/rw9w1Z8STeEKk244ROhuLPG14Tc5Oj2Q5SoWo=",
      "url": "_framework/System.Diagnostics.Tracing.yykvalakbz.wasm"
    },
    {
      "hash": "sha256-IvOqWcdITeDzamSnAm41HZ6ZZw5s+TdJRLabbbwPhHg=",
      "url": "_framework/System.Drawing.Primitives.6ajpvk5hee.wasm"
    },
    {
      "hash": "sha256-iaPXgmZStjRI791gA9FgGZi75saGgt1ZYR8BLjPQVWU=",
      "url": "_framework/System.Drawing.pwn69jd1sx.wasm"
    },
    {
      "hash": "sha256-Y8JLZ0Q+Hq+Ue1lIam/t2R4RHRYTP2hsKwtdLLCFzbY=",
      "url": "_framework/System.Dynamic.Runtime.dwxo8l4rdr.wasm"
    },
    {
      "hash": "sha256-DWjLEno2gKPUwP685ugb0pFCHtmWn4oy4sP6cPEZV/g=",
      "url": "_framework/System.Formats.Asn1.7r6f4x6f4s.wasm"
    },
    {
      "hash": "sha256-z4QPxqj5k7y27vorrM+w5Lb6PKiqGEC/V4iygoxfIRo=",
      "url": "_framework/System.Formats.Tar.9uzzbcwdi8.wasm"
    },
    {
      "hash": "sha256-lVq7a0doxTh2Vdzn7wf95Ec5i6lGujvXY2h51TKCwaQ=",
      "url": "_framework/System.Globalization.Calendars.h9ciwjgoxu.wasm"
    },
    {
      "hash": "sha256-f9c3SyP0tYtSkV1QBevO7XVhgOr7ElNa8MGXINgPyAQ=",
      "url": "_framework/System.Globalization.Extensions.7iv43bve8g.wasm"
    },
    {
      "hash": "sha256-H7Pb+7TbWWnbEng/b6DeLvfgzAUpnKGLFAiKUPT+ztA=",
      "url": "_framework/System.Globalization.xg8c7skko3.wasm"
    },
    {
      "hash": "sha256-bIbkKjMJR7l1Eb5D4ccKG402uQETLvgNDy0Si0Y+6MA=",
      "url": "_framework/System.IO.Compression.Brotli.cgycdoss65.wasm"
    },
    {
      "hash": "sha256-kHfLrKhxx+6ZSM7H39Cj/GOK1BL9i3h1xfZBfsBzD64=",
      "url": "_framework/System.IO.Compression.FileSystem.g80du2epa5.wasm"
    },
    {
      "hash": "sha256-KdcAEnDQx2xDH9z2aM5SNHrnGKuCEyGSYso5pH5pr4I=",
      "url": "_framework/System.IO.Compression.ZipFile.hq70g0m5k0.wasm"
    },
    {
      "hash": "sha256-tY/H2xmqAFiTHnxU8/6WOVCG3oOvp3Q36T+Ri12gYZY=",
      "url": "_framework/System.IO.Compression.ntu9cg6tk2.wasm"
    },
    {
      "hash": "sha256-66BQoQMVYbtLrbMUkas4ERFlUxxAUDkcbDfgDdrF7KA=",
      "url": "_framework/System.IO.FileSystem.AccessControl.bcre3rjv67.wasm"
    },
    {
      "hash": "sha256-ADtnUkdgbU+XmzYlZKS3sdn0JX5AbRpy9rVIiIrGguE=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.gc4k28tlqi.wasm"
    },
    {
      "hash": "sha256-A+TZDIDlLB1ptZp36gHd+RLUU4zM4+ZPOLxudzxPBAc=",
      "url": "_framework/System.IO.FileSystem.Primitives.be43v34w5x.wasm"
    },
    {
      "hash": "sha256-0LzsIBUxLN+Zm/auCG7U7PuycOU4LbpvMbAr0Y0/BdI=",
      "url": "_framework/System.IO.FileSystem.Watcher.8qc3wsh77q.wasm"
    },
    {
      "hash": "sha256-b2xR11S13yOtUTmfYqWUcj4clfG8CpqTAGOcl9BvYSc=",
      "url": "_framework/System.IO.FileSystem.h8uqkh82lb.wasm"
    },
    {
      "hash": "sha256-xApXuMRImNGmM7zijGSXr+yCBzzPE679wsp7tk1sglA=",
      "url": "_framework/System.IO.IsolatedStorage.gzsye4pxc9.wasm"
    },
    {
      "hash": "sha256-+KNHSvZ3txWouIGreidDWZCKCygCEk2aIswbmYp/HKg=",
      "url": "_framework/System.IO.MemoryMappedFiles.4lxw69q3da.wasm"
    },
    {
      "hash": "sha256-LifQPBrvqxFYfjzJY6xu+jsKV85XzBNlkK/ZEecWLLc=",
      "url": "_framework/System.IO.Pipelines.u8n6swt2ok.wasm"
    },
    {
      "hash": "sha256-j3oMbcOE033ryvYZ1UpWgz2JDdzqfyuZoINDD7XY9pc=",
      "url": "_framework/System.IO.Pipes.AccessControl.ddt7du9svb.wasm"
    },
    {
      "hash": "sha256-RyDhQqgIoxLo5y+9F17kNsNkC74iI4n/Lg/T2NwEzyM=",
      "url": "_framework/System.IO.Pipes.tv4o1w1yo1.wasm"
    },
    {
      "hash": "sha256-UUr5CkM630/je64hE0usuhtwSOwZICJaY0IiBqJBvhc=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.jb5bmgvv05.wasm"
    },
    {
      "hash": "sha256-qNqGDefXxtmI6Y2xlF+3wmVeYRdJ7n8L4gdXZEsy8m8=",
      "url": "_framework/System.IO.g204ske44p.wasm"
    },
    {
      "hash": "sha256-aK38b6Cs8BCUvR7kA91s5SkdRfpB5cR1Fd7c2lrlSSs=",
      "url": "_framework/System.Linq.AsyncEnumerable.w2ftt5zfx7.wasm"
    },
    {
      "hash": "sha256-K9cXMgZg9w0hnksRk8PpoKoaHkwjWOMfLAEQXKeHuM0=",
      "url": "_framework/System.Linq.Expressions.rwll9v3f54.wasm"
    },
    {
      "hash": "sha256-5+JiBPrI7kdLCZ7yqsvuIJPNBhR6LtkkXKV8zrBabVM=",
      "url": "_framework/System.Linq.Parallel.78wbzaw40x.wasm"
    },
    {
      "hash": "sha256-29qySGTwBU0h5CGKfGtTw+CY1qfR7D0DIo2sm+6MohI=",
      "url": "_framework/System.Linq.Queryable.bk0gkg2iiv.wasm"
    },
    {
      "hash": "sha256-01WUz7Yv5hQ268Pf7fl0rHnNi25Ck3iSZDLt5m1pe2Y=",
      "url": "_framework/System.Linq.bmrkhne1ox.wasm"
    },
    {
      "hash": "sha256-Jm7+XsbP0Ll97vwpeYJdmR8pUDsLOBOjaEVGq+C9eEc=",
      "url": "_framework/System.Memory.6sz098jj9v.wasm"
    },
    {
      "hash": "sha256-IPslUryM8dVMBqWDGmwJOqFw2NE70E0TKHBKxWXwzTE=",
      "url": "_framework/System.Net.Http.08oi8qoit4.wasm"
    },
    {
      "hash": "sha256-fWzfpAk6aZRzGuXScLDlmyI3EXkyM9CypUDdUa7L6Do=",
      "url": "_framework/System.Net.Http.Json.56y669zj3s.wasm"
    },
    {
      "hash": "sha256-5ujUQXWdkVb8ENZ5zXA4gQJakpvEbymx2RmDHE970Os=",
      "url": "_framework/System.Net.HttpListener.qg0j6amwue.wasm"
    },
    {
      "hash": "sha256-YcW4pvIlOA0n74N6n6fMMsmtQh2G2Rd8wUvc3ag7RGA=",
      "url": "_framework/System.Net.Mail.533n6ks0cq.wasm"
    },
    {
      "hash": "sha256-QDfh/6RWl8mhbIZnLp0F6Ht518QlZNHfFNAGbACj4tY=",
      "url": "_framework/System.Net.NameResolution.s5btvjcq6y.wasm"
    },
    {
      "hash": "sha256-At2HflEs9TiHOLkqi0C9uHSUc6W6ggZl5mmPtQ70h98=",
      "url": "_framework/System.Net.NetworkInformation.ucbqjhtjil.wasm"
    },
    {
      "hash": "sha256-Xnw6mzltKz5abYZcmWscptzw8YDn9G7oKkQqgzZ2L1c=",
      "url": "_framework/System.Net.Ping.ustem6o7fc.wasm"
    },
    {
      "hash": "sha256-RRU91O3azj9Hpy1my1LrAgkWCSQnuJEETf3U1dARGC8=",
      "url": "_framework/System.Net.Primitives.935qhm3yb8.wasm"
    },
    {
      "hash": "sha256-SPl+qTwgQTcGqmoi3kHf2e1Vve6P7Q+rp/B8CNbtDJY=",
      "url": "_framework/System.Net.Quic.cnkjqkyrlb.wasm"
    },
    {
      "hash": "sha256-qY2UjpCNzp3MWqBSN0rWK+NoIqsox2XfMVY6DaSetO8=",
      "url": "_framework/System.Net.Requests.7w1r8uf0a4.wasm"
    },
    {
      "hash": "sha256-Nc4p2mSzW5BUO2Sk5pWpwE7DnOdBE8Laxh+N2ESNMt0=",
      "url": "_framework/System.Net.Security.xlqynrdyot.wasm"
    },
    {
      "hash": "sha256-oWmHBCyId3b5/cbJBZQeU/Y+xXqWotSiIvoMcxat0ZU=",
      "url": "_framework/System.Net.ServerSentEvents.vwcoz3tazw.wasm"
    },
    {
      "hash": "sha256-OPKuJnS12kqgLWBaqqR2p4clW7f/Kz6XqzO1eXZRB14=",
      "url": "_framework/System.Net.ServicePoint.8k7uo97505.wasm"
    },
    {
      "hash": "sha256-8JDtmlYFyYP3Bvv5f9JiGKjhqINet8gjwbERDmn4Exw=",
      "url": "_framework/System.Net.Sockets.krbyf8n4l7.wasm"
    },
    {
      "hash": "sha256-+He4X18r5PRKcxFeDHkC9+5aPZb5ciN8CK3kQcANit8=",
      "url": "_framework/System.Net.WebClient.s7es5vcafa.wasm"
    },
    {
      "hash": "sha256-L5Im66UgOUCTv+gWwTLFnvaC2+14u/dfO0w3KFESBfc=",
      "url": "_framework/System.Net.WebHeaderCollection.9quxghu2aq.wasm"
    },
    {
      "hash": "sha256-nq4JOOk8Mu0Tu8QO2O3gYrIHiYvYBx8hsSumxJK49+I=",
      "url": "_framework/System.Net.WebProxy.ivbmxiwm57.wasm"
    },
    {
      "hash": "sha256-u9wSj7Qki++uQCOriQ5b5jnVPvd8AF6TYzo1cRQbBnI=",
      "url": "_framework/System.Net.WebSockets.Client.x9i7zul9bw.wasm"
    },
    {
      "hash": "sha256-ApeOH9Go2vMvwnpus7yN0CbpFrmVqvrUzyNiqQ4nMa4=",
      "url": "_framework/System.Net.WebSockets.ep3trdpcsb.wasm"
    },
    {
      "hash": "sha256-5cVTGqwp/o594m8mPq30CCXdD5PCuHiSw00BaSNwMoY=",
      "url": "_framework/System.Net.lkc10g164w.wasm"
    },
    {
      "hash": "sha256-xENvAVz3MoraJsO1Do+MFN9aj6L46Rv/go2fyoNjtgM=",
      "url": "_framework/System.Numerics.Vectors.ohk6rx7mq3.wasm"
    },
    {
      "hash": "sha256-ZAhFzKBLuaEJkgnZyMvbo8oBIYU1oY7pWxtfo/3zg4Y=",
      "url": "_framework/System.Numerics.w9sdg2myku.wasm"
    },
    {
      "hash": "sha256-+LHFvGnrKMcSMi+sCz3ls/7Y8KznT+IBB9FGgz3HCnk=",
      "url": "_framework/System.ObjectModel.o49nwl5106.wasm"
    },
    {
      "hash": "sha256-txDQUdiH3VmsOgqRUepjpm922YZKLTGi5aqjJYtcMTE=",
      "url": "_framework/System.Private.CoreLib.9s549gpy7m.wasm"
    },
    {
      "hash": "sha256-uXYok4ofkKh/+NRuBxkTDDA3yo7sgBJeLf+1bK1+lMI=",
      "url": "_framework/System.Private.DataContractSerialization.l1wepxshem.wasm"
    },
    {
      "hash": "sha256-vaJ55eXDUo9PrCfYLiid4iEcArxzTRq0aERdG2wOub0=",
      "url": "_framework/System.Private.Uri.17wno6fz9h.wasm"
    },
    {
      "hash": "sha256-I4P+SLG8x3OY+ffkuKnjFI69+1oRN53/dcu1clzUlWc=",
      "url": "_framework/System.Private.Xml.1znmymukzn.wasm"
    },
    {
      "hash": "sha256-koAzBx3YzD0rGdvPEhKBKpHm+b5E2ZuZlXmAj1bFgZk=",
      "url": "_framework/System.Private.Xml.Linq.6ndmellwxq.wasm"
    },
    {
      "hash": "sha256-8lJBa5yMe9ocAPcf+u2FEMVvtvKlfpGtadJJ9qiA+RY=",
      "url": "_framework/System.Reflection.DispatchProxy.uhng0i33yv.wasm"
    },
    {
      "hash": "sha256-BiohgywrtvUlQ9yweDjQ42xVwKvXvkRWqQ8oOS6AT/U=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.mki4j8yrd1.wasm"
    },
    {
      "hash": "sha256-NX9QaiN1pdiDQUvzVp22sBxPq7qb1h286QrFavpuy3M=",
      "url": "_framework/System.Reflection.Emit.Lightweight.rwbaytvlax.wasm"
    },
    {
      "hash": "sha256-pAN3h4XuXHIgJ8N41G135W2oE4YV8nEXX5Pwby0UT5k=",
      "url": "_framework/System.Reflection.Emit.sioal9node.wasm"
    },
    {
      "hash": "sha256-vxPC8Lknhll6pYAa+m93AyDMrs5YBR6JzCmZUZtbWvU=",
      "url": "_framework/System.Reflection.Extensions.j3sy1079ix.wasm"
    },
    {
      "hash": "sha256-WTe8k2LAdrTBQ7WnMhCgrSw9Ec9lBDpDsJ9f9hdLrxg=",
      "url": "_framework/System.Reflection.Metadata.jppm5mm49v.wasm"
    },
    {
      "hash": "sha256-MQtgnTwTHMtaT/DvGALvcRBAjJyIDjtzGcOfjvDrd7E=",
      "url": "_framework/System.Reflection.Primitives.td0lyduqh2.wasm"
    },
    {
      "hash": "sha256-Varexc6bfsick0m07M5v70eo7ESJJoe5x16sRVRFd6o=",
      "url": "_framework/System.Reflection.TypeExtensions.bw6raolkdi.wasm"
    },
    {
      "hash": "sha256-/Z9nzWOLfEe/X8opJD3DYvv9M4a9XlFDkVkiD9nL2Nw=",
      "url": "_framework/System.Reflection.vtl64yeamf.wasm"
    },
    {
      "hash": "sha256-4SzOk8ZsFz3dJqEv8Fxp7ovBvYMrh9eLR8tL6DEZHCw=",
      "url": "_framework/System.Resources.Reader.v4f2264f3m.wasm"
    },
    {
      "hash": "sha256-lPHfv+UMo6+cO5sShlE+9SjMel1I2JgTWBw/WbMZIAc=",
      "url": "_framework/System.Resources.ResourceManager.wfbqycsq2f.wasm"
    },
    {
      "hash": "sha256-IqZrJO3pSEU3l8PLAHs6dHyhf6tBXW4Kd03oQlJX9/U=",
      "url": "_framework/System.Resources.Writer.yomp7oq8px.wasm"
    },
    {
      "hash": "sha256-Ws0TMOkKaNQMKuS+Fshtw+92XVxaFCimL/bkvDLq9DU=",
      "url": "_framework/System.Runtime.6x7t8axmdw.wasm"
    },
    {
      "hash": "sha256-wXC73+lTf8SQZxg7fIN2JaI1aKh71Z5tuNtZLp+rjGI=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.3fy8j39bry.wasm"
    },
    {
      "hash": "sha256-Ufl48Z38OOFBpwxI6Hg3TQlHVe5gMkgRAS6tgq45Sd4=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.lzt2t2jx25.wasm"
    },
    {
      "hash": "sha256-D7U74t7jbJRnfpa9v5g9GvG2xUimYX/yBzd+nTEef5w=",
      "url": "_framework/System.Runtime.Extensions.bllnsrspwd.wasm"
    },
    {
      "hash": "sha256-9+ASatqkwUS5JQeNsDnxqx7qbEjguRM/mj0dnx5TpsY=",
      "url": "_framework/System.Runtime.Handles.l1doztbysk.wasm"
    },
    {
      "hash": "sha256-jzLv11RwmdCK+0szbQUORqhqWV4qbY/fJXbFKK1jn6c=",
      "url": "_framework/System.Runtime.InteropServices.92mbh6ougs.wasm"
    },
    {
      "hash": "sha256-tq5pToZJGO7SPoDjoI6ztMHmMkRlFnxE1syzsag+I2E=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.a0smuvq74f.wasm"
    },
    {
      "hash": "sha256-tZytQU9Ot9cWvPshR0e0K8sL/w8AP6NwtvIIGULv0SI=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.9rm6cit8v0.wasm"
    },
    {
      "hash": "sha256-ClZynzaqD2k+36tnRxpIMIgLWf3mFLGMeiPJsNCky+s=",
      "url": "_framework/System.Runtime.Intrinsics.m5kkftjqir.wasm"
    },
    {
      "hash": "sha256-hHJDGEgMAWr1s+qiW1BrV+1Z7exLoySo/6fOWJqrd3A=",
      "url": "_framework/System.Runtime.Loader.8tidl2vik3.wasm"
    },
    {
      "hash": "sha256-1ui5OHMJ7wPS8CMagRQST8GZ+0fbZ/9pltkCoT+90pM=",
      "url": "_framework/System.Runtime.Numerics.ym3nhl4pae.wasm"
    },
    {
      "hash": "sha256-0e07W2MjfznHKpgHXH4mF/uPkhswpfke9rEm8SzrIpc=",
      "url": "_framework/System.Runtime.Serialization.Formatters.jfoer9a9b1.wasm"
    },
    {
      "hash": "sha256-sLc2UXv86/7spmjl9k/FlzZJtgLB91oVoAjVSMmI64A=",
      "url": "_framework/System.Runtime.Serialization.Json.04ot9ggpin.wasm"
    },
    {
      "hash": "sha256-4R6za3QhAG738JhwTSlKYmmVUewZL3+JEiy2EBTBZkY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.v0sloygu0k.wasm"
    },
    {
      "hash": "sha256-qZRNlDomw6MJdamd4o5xAXyVc89w8VvVilN0uYK+IYU=",
      "url": "_framework/System.Runtime.Serialization.Xml.l9p36z8pw0.wasm"
    },
    {
      "hash": "sha256-4H3w8zpYK/k5VcLN3klMmYqX9gmmcmLJDWGp/xNzDS0=",
      "url": "_framework/System.Runtime.Serialization.sl1f80ke8z.wasm"
    },
    {
      "hash": "sha256-gaQKfUFeWC/yC+vIXYGwISG7E0h347ZKZFxR/rMFCwc=",
      "url": "_framework/System.Security.AccessControl.3nwl7fw3mc.wasm"
    },
    {
      "hash": "sha256-ndi9w48lPV0EGw6ddNHDBcPoYQbPWSE3/SEuHecjHoc=",
      "url": "_framework/System.Security.Claims.xz90ei9jt5.wasm"
    },
    {
      "hash": "sha256-/2jRTOBlxI2qAsJecgUlKA7HPIDGfC4FSSyvPvlXduo=",
      "url": "_framework/System.Security.Cryptography.Algorithms.p2act7isih.wasm"
    },
    {
      "hash": "sha256-nxpZpScv6JOfnBL71rSVmbIJSvAulY3TLi8FsHGXimo=",
      "url": "_framework/System.Security.Cryptography.Cng.x43abjiulr.wasm"
    },
    {
      "hash": "sha256-hivAoL3huWK/hEsopqiDNzD2Q6LaTS0V13mwDvU45zA=",
      "url": "_framework/System.Security.Cryptography.Csp.ujvbo6nowk.wasm"
    },
    {
      "hash": "sha256-LElRZ2Qff7na2E+Ht9jLV7zIfkfGWk5ZGEe6X9rwEYM=",
      "url": "_framework/System.Security.Cryptography.Encoding.87lifboqsx.wasm"
    },
    {
      "hash": "sha256-xvSMbbP5mYs78WPxfabMxS6CEiVXXW/z8DHAd06Ta9w=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.u2qntds71c.wasm"
    },
    {
      "hash": "sha256-uoVej/K2vISCzdMszNTRCw8JHuzCyCjDp8gZotB5KZE=",
      "url": "_framework/System.Security.Cryptography.Primitives.ei71q5x4j1.wasm"
    },
    {
      "hash": "sha256-fqvts/KgaVC7h71J3M5xks4Qm3qnemRlLg9paDnsBm8=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.2spowjj5l2.wasm"
    },
    {
      "hash": "sha256-P91IL4b6yQRR9l71weSqfJ9rOXTRBEZI4DHXNPgKQTo=",
      "url": "_framework/System.Security.Cryptography.na4q58ou4y.wasm"
    },
    {
      "hash": "sha256-REeNMiKakK0i+LDpQR0G3oIO8RHhAlL2UI+0CW7mxNE=",
      "url": "_framework/System.Security.Principal.Windows.w9a1l2myly.wasm"
    },
    {
      "hash": "sha256-AXZeh8L/uen1b1P66TzL/H/2MUPuRm/CSLFrXqLfrDE=",
      "url": "_framework/System.Security.Principal.bh1imzrvgv.wasm"
    },
    {
      "hash": "sha256-TwpwRnrNs27dbje6sMEyhXmdicvOpBted27udig6sTI=",
      "url": "_framework/System.Security.SecureString.x4k3li7xsu.wasm"
    },
    {
      "hash": "sha256-MZseoEAYl49td4OBMPYnTVFqg4ab7Q4lhtQKSYVjRfM=",
      "url": "_framework/System.Security.xcu685weif.wasm"
    },
    {
      "hash": "sha256-J16MH06/hNRpUncDtgqLUlkzHraiCdEChHC3tlESOG0=",
      "url": "_framework/System.ServiceModel.Web.bj3h2scdlc.wasm"
    },
    {
      "hash": "sha256-/VUsU+8LpVIGBsJ1in3k4k+oT2Ge2My8YuSWCIQATCg=",
      "url": "_framework/System.ServiceProcess.5a1uwxr095.wasm"
    },
    {
      "hash": "sha256-IfZW7z5urfuADmp1nHcnlH+MShrRjbc8KxlXi9SqOOM=",
      "url": "_framework/System.Text.Encoding.CodePages.bxr2gc97io.wasm"
    },
    {
      "hash": "sha256-uoSlDj/RP4D2q3z3Mw3VrUm19I7Fo7xOZfT5XzvpXyk=",
      "url": "_framework/System.Text.Encoding.Extensions.ar7spvhfea.wasm"
    },
    {
      "hash": "sha256-F5CjAxi2QCwntYK4j4UOtDegwSjxrZS4XYVZMFAHuhQ=",
      "url": "_framework/System.Text.Encoding.z1tsijp8tc.wasm"
    },
    {
      "hash": "sha256-kk8Pc1Ur6Uul8F3nt+GPXzvBTnzgSIxM4vdWNJQbU+Q=",
      "url": "_framework/System.Text.Encodings.Web.ecvfozax9d.wasm"
    },
    {
      "hash": "sha256-u3/5pDXPp1eZr4wgxyiFy0TOQgg8ibzjBJG/Ed7YQ4M=",
      "url": "_framework/System.Text.Json.t2y3tht3ok.wasm"
    },
    {
      "hash": "sha256-llRhUd8PtG73MH2dI6tpZGZxISRKAn4l/bDru8ma/nw=",
      "url": "_framework/System.Text.RegularExpressions.qwxrrj2acp.wasm"
    },
    {
      "hash": "sha256-G51WQ7j03lstpVgFIS/Rgx9Ei7vwZLqoTddlzUCBzaE=",
      "url": "_framework/System.Threading.7dgt1d3mf6.wasm"
    },
    {
      "hash": "sha256-UeiDPJNkvktS+ZHXy5yEvXt6rnrqX4PxuwzgrHFmnS8=",
      "url": "_framework/System.Threading.AccessControl.9ykh0d964r.wasm"
    },
    {
      "hash": "sha256-zNpzMcNMjctVEjN+LqhOMsphJ2pOVztYiWXaOO+25ZI=",
      "url": "_framework/System.Threading.Channels.kqljytjj5u.wasm"
    },
    {
      "hash": "sha256-tuNpEI8jQs7rbsph7idVqHCnCY/pzMmZRqoLnGGMvZo=",
      "url": "_framework/System.Threading.Overlapped.aw0j9ufvn4.wasm"
    },
    {
      "hash": "sha256-sFWZt9uAGjanOJVHa7llIVf5qVeKRIp1FFo2UfHLZx8=",
      "url": "_framework/System.Threading.Tasks.Dataflow.gsdu90uund.wasm"
    },
    {
      "hash": "sha256-ISzNUJ/eFCKfXPMRBqZg+Rlqf2tXnLTOrIsIuaRAoSM=",
      "url": "_framework/System.Threading.Tasks.Extensions.bxz0ahfwn3.wasm"
    },
    {
      "hash": "sha256-TltUJqcCWphq9MN5/g3hVFqm5phD5d5Y5ICxEgONuBU=",
      "url": "_framework/System.Threading.Tasks.Parallel.m6q3sy58px.wasm"
    },
    {
      "hash": "sha256-G2p7e/b1thoMgqV+/VcmMWKgaVN3zSNfApUd54HG1PU=",
      "url": "_framework/System.Threading.Tasks.vr7balnlm6.wasm"
    },
    {
      "hash": "sha256-4ov9QfcmtHwHRwpxCXAsKH4g3veXT8rI3FbsEW89Zm8=",
      "url": "_framework/System.Threading.Thread.yoidgvo6hg.wasm"
    },
    {
      "hash": "sha256-xta6KYtN6poMtdBSQbH3CTNjayPc1HEaCXZnwC5v9F4=",
      "url": "_framework/System.Threading.ThreadPool.ylzen93rxt.wasm"
    },
    {
      "hash": "sha256-7t2V9QZ4oI7StPrXJhUOQ1iQnRNqIiLKjRi4uVRFQOs=",
      "url": "_framework/System.Threading.Timer.ai8c4yy4gy.wasm"
    },
    {
      "hash": "sha256-YWBAk4+509RyG20xmF8GrmkC4sigz0LUX6jWck0sFYk=",
      "url": "_framework/System.Transactions.Local.lzy5oi4lqx.wasm"
    },
    {
      "hash": "sha256-K8uoLN/UN2qdfmJT9XTYrNxmI2VoUC2Jrqoc534LSSI=",
      "url": "_framework/System.Transactions.t2zd200496.wasm"
    },
    {
      "hash": "sha256-d4etbGmiQtcQ25lQP+/DjZsS1rqs5vw2JVObdI8IMXc=",
      "url": "_framework/System.ValueTuple.7wn6he28cp.wasm"
    },
    {
      "hash": "sha256-qr42CBau61hV8Bc9xTDtRzHthtHhg/xit/+HAsdTiqE=",
      "url": "_framework/System.Web.HttpUtility.6tp4nz4hbm.wasm"
    },
    {
      "hash": "sha256-FteOHi1+0r+SGe0svuqML4XCBC3B/PiupXgkQFjqB/A=",
      "url": "_framework/System.Web.ebdit25xqb.wasm"
    },
    {
      "hash": "sha256-UmXZ2xzXZIwSArLJnHQKjfyFNH56w4sRe4Z4egHlwxg=",
      "url": "_framework/System.Windows.aq6lwwfr3z.wasm"
    },
    {
      "hash": "sha256-KJ9OjBdfB9r+m4yEC31C17mLDPbgDqHCknx0g2IACwQ=",
      "url": "_framework/System.Xml.4dgsvowdwq.wasm"
    },
    {
      "hash": "sha256-uWnWhnYQtarrd5PsokR9QKk0fsUwI4oFad4rx0VBQGM=",
      "url": "_framework/System.Xml.Linq.b7gdbqfifs.wasm"
    },
    {
      "hash": "sha256-2o8zaXKRoPKOFJ7IrUCXwSbXzm77CYg+jqnzkXYm2qM=",
      "url": "_framework/System.Xml.ReaderWriter.y98l7nfpbl.wasm"
    },
    {
      "hash": "sha256-79DtH9ut2lkny/R8gyJGHraPPQzvgEH5tRXB5wmh064=",
      "url": "_framework/System.Xml.Serialization.7yexjpd5e3.wasm"
    },
    {
      "hash": "sha256-EQYoTyz3fqjCQ/5iFxAnoR81oKunRdddg6LZdVAqMWk=",
      "url": "_framework/System.Xml.XDocument.vg9k1j0zjc.wasm"
    },
    {
      "hash": "sha256-nMReov8iBoHa8IEuE+MUl62tVe9irNcWbeLVIy44lXw=",
      "url": "_framework/System.Xml.XPath.XDocument.kwdgho41kx.wasm"
    },
    {
      "hash": "sha256-/xTzME6qvVBigmgDbmVEVp/FiIcVmiqdcZAJkU11zLY=",
      "url": "_framework/System.Xml.XPath.b1ds872h3h.wasm"
    },
    {
      "hash": "sha256-KSTTCxTwFkS8RtZg1NdpyxnM94/yUsOywQjy4XTa6kU=",
      "url": "_framework/System.Xml.XmlDocument.7obbgjtztj.wasm"
    },
    {
      "hash": "sha256-sYHb48y2hJbaWT2iDShSJefi0STSVUdV/ipwhbIZo+o=",
      "url": "_framework/System.Xml.XmlSerializer.vgjr3kbu2b.wasm"
    },
    {
      "hash": "sha256-J62Baw7gfV8sK5XwURj1GDN87DYteBFag2haGMDvA6M=",
      "url": "_framework/System.bv0vfagjd5.wasm"
    },
    {
      "hash": "sha256-x6awrG0PK6N88ErLKZtswG2jfcmeesJojz0dPh3MvME=",
      "url": "_framework/WindowsBase.fin39dxgo4.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.958z1vx7fr.js"
    },
    {
      "hash": "sha256-CMGy9ybQd5JiyOrbA8zPcKD0JnkkWV4HdLg6jAPmbb8=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-kkp5wX0htwkBcZt5WmEiKmhBqjqdCJtGc+koldfyoDQ=",
      "url": "_framework/dotnet.native.ikrs475e5v.js"
    },
    {
      "hash": "sha256-iQOJ2Ignl/X3n6mOHRQ4zWYcute0MGlaiRFi2J3HXWk=",
      "url": "_framework/dotnet.native.veuqw8a0w9.wasm"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZ4sNWTUrCBrLhvMdb1QLMIEA8vmZDV6h4zfJrz8Poo=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-YETvzSFhIHCtXnj9hRig3SWqJq1V/3dYqbxlnmDl79Y=",
      "url": "_framework/dotnet.w002jznuqh.js"
    },
    {
      "hash": "sha256-tKthmyNllphy6TL87okXxhnFaTwmwnCxx+UTa1c40Dg=",
      "url": "_framework/icbt ride.oneazoibap.wasm"
    },
    {
      "hash": "sha256-M8QE0lmREMIg7a9W6OMohoqGItSJqahIcHRx24EVWgY=",
      "url": "_framework/icbt ride.v9hv7lsbd7.pdb"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-dC5aSPpW8ylC2bmsSpcll/w4ThaEhnL/KEwOF3TQQcw=",
      "url": "_framework/mscorlib.83s5ln6r4i.wasm"
    },
    {
      "hash": "sha256-+tPP7i1i4Q/boVeZgA7ptN+InVDWoJbxot5eS/i9fqY=",
      "url": "_framework/netstandard.qv9s71s9sf.wasm"
    },
    {
      "hash": "sha256-cMLpBqJccEbuOr9yJAv97kc4whp+NHFcG4pCzDdXsfE=",
      "url": "admin-dashboard/admin-login.html"
    },
    {
      "hash": "sha256-i+Rf0mJ/Ktfa4Ky/gYZUgZj0xXoN25JoHt6hpzdPDXQ=",
      "url": "admin-dashboard/announcements.html"
    },
    {
      "hash": "sha256-0MPW/Gls1YYFmhLjwr3Twxh+OsHb3YZFr0ustSsRVW8=",
      "url": "admin-dashboard/complaints.html"
    },
    {
      "hash": "sha256-TG+OEKcAdK3Ut8+XdsIfSlPO+8kZn/ZpY1NFwXjyoi8=",
      "url": "admin-dashboard/css/style.css"
    },
    {
      "hash": "sha256-WIJczGqYsF/axlSexYNj1dns8GkJgZRorxGMiwKIwhY=",
      "url": "admin-dashboard/dashboard.html"
    },
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": "admin-dashboard/icon.svg"
    },
    {
      "hash": "sha256-9fFxZGbNlFVR20r0rQ7CiMVQckZjq/mTl5E1WR2Skok=",
      "url": "admin-dashboard/js/firebase-config.js"
    },
    {
      "hash": "sha256-5CkZe4ThW2+pSRwFBFFEis1H16sa8Te5JUyQyKEPMBA=",
      "url": "admin-dashboard/manifest.json"
    },
    {
      "hash": "sha256-BR4L62NwuQ7zFRsx2VsfBu8B0bHd5MkuHKv8XEgGLKE=",
      "url": "admin-dashboard/rides.html"
    },
    {
      "hash": "sha256-l0idzFh9iAjHvrHZnm6t5WyQzS7TKfLrYjHi883sBwE=",
      "url": "admin-dashboard/sw.js"
    },
    {
      "hash": "sha256-v2T5SYa6xqH+oT/LNFUFHHQf77scblr5ikdnIXn4t3U=",
      "url": "admin-dashboard/users.html"
    },
    {
      "hash": "sha256-CsChHlHUYGbuIEdR+5X9lxWNazWkgwxEsDPWRPQmRpQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SJHJ8Kag7n+h90OOcAvpyR98ZNZ5XB7TpwNLVSLNQhU=",
      "url": "driver-dashboard/app.js"
    },
    {
      "hash": "sha256-V0iPc84g969TCCelD5FEZ3N/BAFy6OfBMyKvVKY9N2U=",
      "url": "driver-dashboard/driver_dashboard.html"
    },
    {
      "hash": "sha256-VCCN1IZbBV3t0y80ooc3daUjZ7wFgkUimglpC3BpwQ8=",
      "url": "driver-dashboard/profile.html"
    },
    {
      "hash": "sha256-kEW8TKIoCi+xEAqiw5X00NOzAVF7ExGyxt5iGCHiME8=",
      "url": "driver-dashboard/requests.html"
    },
    {
      "hash": "sha256-UYnXfg9OJ4D3Fh21V9Ynnwjw3uLCuX7lbW91G4rii8k=",
      "url": "driver-dashboard/rides.html"
    },
    {
      "hash": "sha256-EDWwyLzOM6XA6apHSQ9CzstNHGz9QId1XKJ4IdbpoWQ=",
      "url": "driver-dashboard/sustainability.html"
    },
    {
      "hash": "sha256-ZrEKRizdNtop1ajk1u/+LuBuv+L/ciTEkaAjEiZKxnQ=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-87eQFFxzRClXI2Td3fXgJSMVlZZ56CQ6QytrUEjeXL0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-q2UBKsLylocusXwTojOaIsxaDwQp/o4tULQgFTm53Wk=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-mv70aaa+4uQYfw0aOERLCKegEal6Q0aJvIBtSDEqi9A=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ieOV597a3rlODGe6Rp/+z5HjYJ5dLASDVr0v4O3DYS0=",
      "url": "js/firebase-config.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-4sikSSnA1XMZcg7uPJpSKGJvW6VjFjkIDDUsXJlLq0Q=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-fouYCEAzi9tDXjjFOadtabFtLhYrN+7/GFRnVbg/jM0=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-dvqnQfh5YxZ8T6vCK0ZrVoRnFLwwg2npH6tKZ1Mo7/o=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-kR5J10LAqh1wANrMJdelvAB/yK48yglmZUH3mWXI5VQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-ubaLyeg6mH89cbF/6N1mlvHe3uefOrUG1fZCMu1rYj4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-KBwnZIC/s2SDrSVKJggm/Dys27jZpK6yViyBlDwapYs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-DM8LjIXvKUAq7IkG8F476bj4JolxG8/kbSVWqJc9MDU=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-RvvRB1TjLtIXoyxsZtQ15CrLOO0Vwe8tNVJhEoaZ8ps=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-BBezhWsmJcIMfiKrU+p2fM8bATgUZu+tlOg4yJxUaKs=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-VbOTmds0s7X3K/pJiPIEfDX4pB+VoexyVDfefbn6MAk=",
      "url": "main-login/css/style.css"
    },
    {
      "hash": "sha256-FODnumPQtBU1k3CXIq+ImiElV8OKJlYwlmsEdafQZXw=",
      "url": "main-login/login.html"
    },
    {
      "hash": "sha256-q/jEY9kNMJIHOCpqaG02ANGWCppiO6hSYRkg9/chpYM=",
      "url": "main-login/register.html"
    },
    {
      "hash": "sha256-H6MZO7kf2bgTF4lMAVpo6oI1nl0C2Wte1eM/O5gea2A=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-7OZ7Pk5x/8L9WyjbIIXDOCxgTuZ78f3bF6fzzx/RU4U=",
      "url": "owner-dashboard/drivers.html"
    },
    {
      "hash": "sha256-PjJ7TEL+u4aCoDbYWYOp1dBoFjiVBTJ2yZd3C9aHgT8=",
      "url": "owner-dashboard/js/owner-app.js"
    },
    {
      "hash": "sha256-gDYmPIS+QJ5AP2TZDuo5e6TZaL4lH+w9gi4u88bvs+o=",
      "url": "owner-dashboard/owner_dashboard.html"
    },
    {
      "hash": "sha256-hsbIFEVm3MxiShlhqAgDCriYh9aISR092QvzwkbUwM0=",
      "url": "owner-dashboard/profile.html"
    },
    {
      "hash": "sha256-Wvbyw9Xc0lo2pHnz4KMcDdCAu1f5d549sSdDHhy8060=",
      "url": "owner-dashboard/rides.html"
    },
    {
      "hash": "sha256-vKHRhkGpcFjpcOtJjHoG2Ay/HTMNN+4lEne+0163nJY=",
      "url": "owner-dashboard/vehicles.html"
    },
    {
      "hash": "sha256-yRZ013LJkyskO1aXRAXDgiZxRfdioQACqWVMFf3vMqM=",
      "url": "passenger-dashboard/app.js"
    },
    {
      "hash": "sha256-/jDIAx7KhQqm2vsRJuwWHr10vMHPeNmPmGr3MLJOWpQ=",
      "url": "passenger-dashboard/bookings.html"
    },
    {
      "hash": "sha256-U7uhmP1/2j/dWSj4dEx65dCR+8r4304zHI/ia5GUWsM=",
      "url": "passenger-dashboard/logo.png"
    },
    {
      "hash": "sha256-2nSJ+W/DkiHk1m+2YWShT05N7od1DXndAIJ3LzmeQ9Y=",
      "url": "passenger-dashboard/passenger_dashboard.html"
    },
    {
      "hash": "sha256-XCUjNkU/lPpIuTbOHbgEpka12hcYMVtpWSmDrMtcuos=",
      "url": "passenger-dashboard/profile.html"
    },
    {
      "hash": "sha256-U+ZforEBrlDeonCSXvxZjO8RhVZ5BmfX9OQlYGqIzR0=",
      "url": "passenger-dashboard/search_rides.html"
    }
  ]
};
